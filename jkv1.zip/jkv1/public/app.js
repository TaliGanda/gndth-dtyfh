const $ = (sel) => document.querySelector(sel);
const fmt = (v) => v ?? '-';

let currentType = 'http';
let currentMode = 'method1';
let liveStream = null;

function token() {
  return localStorage.getItem('adminToken') || '';
}

async function api(path, opts = {}) {
  const headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
  if (token()) headers['x-admin-token'] = token();
  const res = await fetch(path, { ...opts, headers });
  const isJSON = (res.headers.get('content-type') || '').includes('application/json');
  const data = isJSON ? await res.json() : await res.text();
  if (!res.ok) throw new Error((data && data.error) || `HTTP ${res.status}`);
  return data;
}

function setModeUI(mode) {
  currentMode = mode;
  document.querySelectorAll('.seg[data-mode]').forEach((b) => b.classList.toggle('active', b.dataset.mode === mode));
}

function setTypeUI(type) {
  currentType = type;
  document.querySelectorAll('.seg.export').forEach((b) => b.classList.toggle('active', b.dataset.type === type));
}

async function refreshStatus() {
  const data = await api('/api/status');
  $('#schedulerState').textContent = data.scheduler.running ? 'RUNNING' : 'STOPPED';
  $('#activeMode').textContent = data.state.activeMode || '-';
  $('#totalProxy').textContent = data.counts.total;
  $('#lastRunAt').textContent = data.state.lastRunAt || '-';
  setModeUI(data.state.activeMode || 'method1');
  await refreshProxyText();
}

async function refreshProxyText() {
  const res = await fetch(`/api/proxies?type=${currentType}`);
  $('#proxyText').textContent = await res.text();
}

async function refreshLogs() {
  const data = await api('/api/logs?limit=80');
  const el = $('#logList');
  el.innerHTML = '';
  data.logs.forEach((item) => {
    const div = document.createElement('div');
    div.className = 'log-item';
    div.innerHTML = `<strong>${item.event || 'log'}</strong><small>${item.ts || ''} · ${item.level || ''}<br>${JSON.stringify(item)}</small>`;
    el.appendChild(div);
  });
}

async function loadLicenses() {
  const data = await api('/api/licenses');
  const el = $('#licenseList');
  el.innerHTML = '';
  data.licenses.forEach((lic) => {
    const div = document.createElement('div');
    div.className = 'license-item';
    div.innerHTML = `
      <strong>${lic.key}</strong>
      <small>Status: ${lic.status} · Created: ${lic.createdAt || '-'} · Exp: ${lic.expiresAt || 'none'}<br>${lic.note || ''}</small>
      <div style="margin-top:10px"><button class="ghost revoke">Revoke</button></div>
    `;
    div.querySelector('.revoke').onclick = async () => {
      await api(`/api/licenses/${lic.id}/revoke`, { method: 'POST', body: '{}' });
      await loadLicenses();
    };
    el.appendChild(div);
  });
}

function connectLiveUpdates() {
  try {
    if (liveStream) liveStream.close();
    liveStream = new EventSource('/api/events');
    liveStream.addEventListener('proxy-update', () => {
      refreshProxyText().catch(() => {});
      refreshStatus().catch(() => {});
    });
    liveStream.addEventListener('scan-status', () => {
      refreshStatus().catch(() => {});
      refreshLogs().catch(() => {});
    });
    liveStream.onerror = () => {
      setTimeout(connectLiveUpdates, 3000);
    };
  } catch {
    setTimeout(connectLiveUpdates, 3000);
  }
}

$('#adminToken').value = localStorage.getItem('adminToken') || '';
$('#saveToken').onclick = () => {
  localStorage.setItem('adminToken', $('#adminToken').value.trim());
  refreshStatus().catch(alert);
};

document.querySelectorAll('.seg[data-mode]').forEach((btn) => {
  btn.onclick = async () => {
    setModeUI(btn.dataset.mode);
    await api('/api/method', { method: 'POST', body: JSON.stringify({ mode: btn.dataset.mode }) });
    await refreshStatus();
  };
});

document.querySelectorAll('.seg.export').forEach((btn) => {
  btn.onclick = async () => {
    setTypeUI(btn.dataset.type);
    await refreshProxyText();
  };
});

document.querySelectorAll('button[data-action]').forEach((btn) => {
  btn.onclick = async () => {
    const action = btn.dataset.action;
    if (action === 'start') await api('/api/scheduler/start', { method: 'POST', body: '{}' });
    if (action === 'stop') await api('/api/scheduler/stop', { method: 'POST', body: '{}' });
    if (action === 'scrape') await api('/api/scrape/run', { method: 'POST', body: '{}' });
    if (action === 'refresh') await api('/api/refresh', { method: 'POST', body: '{}' });
    await refreshStatus();
    await refreshLogs();
  };
});

$('#copyProxy').onclick = async () => {
  await navigator.clipboard.writeText($('#proxyText').textContent || '');
};

$('#reloadLogs').onclick = refreshLogs;
$('#loadLicenses').onclick = loadLicenses;
$('#createLicense').onclick = async () => {
  const days = Number($('#licenseDays').value || 0);
  const note = $('#licenseNote').value.trim();
  await api('/api/licenses', { method: 'POST', body: JSON.stringify({ days, note }) });
  $('#licenseDays').value = '';
  $('#licenseNote').value = '';
  await loadLicenses();
};

(async () => {
  setTypeUI(currentType);
  await refreshStatus().catch(console.error);
  await refreshLogs().catch(console.error);
  await loadLicenses().catch(console.error);
  connectLiveUpdates();
  setInterval(() => {
    refreshStatus().catch(() => {});
    refreshLogs().catch(() => {});
  }, 15000);
})();
