# Proxy Dashboard Pro

Dashboard proxy list yang berjalan otomatis, tanpa `.env`, dan memakai file JSON sebagai penyimpanan konfigurasi serta data.

## Fitur
- Dashboard web rapi untuk status proxy, log, dan kontrol scheduler
- Scrape otomatis tiap 2 jam
- Validasi proxy via **metode 1** (Node.js `net.Socket` + `CONNECT`)
- Integrasi **metode 2** via command eksternal yang bisa diarahkan ke `proxy.go`
- Export proxy dalam format plain text per baris
- Manajemen license untuk endpoint export
- Penyimpanan hasil, cache sementara, dan log aktivitas
- Start/stop/test/refresh dari dashboard

## Struktur
- `server.js` — server utama
- `lib/` — scraper, checker, license, storage, scheduler, logger
- `public/` — dashboard frontend
- `data/` — konfigurasi dan hasil runtime
- `tools/` — tempat meletakkan alat bantu eksternal, termasuk `proxy.go`

## Menjalankan
1. Pastikan Node.js versi 18+.
2. Jalankan:
   ```bash
   ./start.sh
   ```
   atau:
   ```bash
   node server.js
   ```
3. Buka:
   - Dashboard: `http://127.0.0.1:5000`
   - Export: `http://127.0.0.1:5000/api/export?license=LICENSE_ANDA&type=http`

Saat pertama kali dijalankan, aplikasi akan membuat:
- `data/config.json`
- `data/licenses.json`
- `data/proxies.json`
- `data/logs.jsonl`
- `data/state.json`

## Catatan penting
- File konfigurasi tidak disimpan di web; semuanya ada di disk lokal.
- Endpoint admin memakai `x-admin-token`.
- `tools/proxy.go` sudah disertakan sebagai checker metode 2 yang dibangun ulang dari nol.

## Contoh request export
```bash
curl "http://127.0.0.1:5000/api/export?license=LICENSE_ANDA&type=socks5"
```

## Struktur data
Hasil proxy disimpan per tipe:
- `http`
- `https`
- `socks4`
- `socks5`

Format output selalu plain text, satu proxy per baris.
