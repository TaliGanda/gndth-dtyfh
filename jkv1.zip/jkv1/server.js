const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { EventEmitter } = require('events');

const { ensureDir, readJSON, writeJSONAtomic, readTextIfExists } = require('./lib/storage');
const { createLogger } = require('./lib/logger');
const { createLicenseManager } = require('./lib/license');
const { scrapeAndProcess, rescanSavedProxies } = require('./lib/pipeline');
const { createScheduler } = require('./lib/scheduler');
const { getProxySnapshot, saveProxySnapshot, getState, saveState } = require('./lib/state');
const { sendJSON, sendText, parseBody, serveStatic, notFound, unauthorized, forbidden, badRequest } = require('./lib/http');
const { normalizeType } = require('./lib/proxy');

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const PUBLIC_DIR = path.join(ROOT, 'public');
const CONFIG_PATH = path.join(DATA_DIR, 'config.json');
const LICENSES_PATH = path.join(DATA_DIR, 'licenses.json');
const PROXIES_PATH = path.join(DATA_DIR, 'proxies.json');
const LOGS_PATH = path.join(DATA_DIR, 'logs.jsonl');
const STATE_PATH = path.join(DATA_DIR, 'state.json');
const DAILY_RESCAN_MS = 24 * 60 * 60 * 1000;

ensureDir(DATA_DIR);

function defaultConfig() {
  return readJSON(path.join(ROOT, 'config.example.json'));
}

function loadOrInitConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    const cfg = defaultConfig();
    if (cfg?.security?.adminToken === 'CHANGE_ME_ADMIN_TOKEN') {
      cfg.security.adminToken = crypto.randomBytes(16).toString('hex');
    }
    writeJSONAtomic(CONFIG_PATH, cfg);
    return cfg;
  }
  return readJSON(CONFIG_PATH);
}

const config = loadOrInitConfig();
const logger = createLogger(LOGS_PATH);
const licenseManager = createLicenseManager({ licensesPath: LICENSES_PATH, logger });
const liveFeed = new EventEmitter();
liveFeed.setMaxListeners(0);
const scheduler = createScheduler({
  enabled: Boolean(config.scheduler?.enabled),
  intervalMinutes: Number(config.scheduler?.intervalMinutes || 120),
  runTask: (reason) => runScrape(reason),
  logger
});

let scanBusy = false;
let dailyRescanTimer = null;

function adminAuth(req) {
  const token = req.headers['x-admin-token'];
  return token && token === config.security?.adminToken;
}

function rateLimiter() {
  const bucket = new Map();
  return (key, limitPerMinute) => {
    const now = Date.now();
    const windowStart = now - 60_000;
    const arr = bucket.get(key) || [];
    const filtered = arr.filter((t) => t >= windowStart);
    if (filtered.length >= limitPerMinute) return false;
    filtered.push(now);
    bucket.set(key, filtered);
    return true;
  };
}

const canExport = rateLimiter();

function sendEvent(res, event, data) {
  res.write(`event: ${event}\n`);
  res.write(`data: ${JSON.stringify(data)}\n\n`);
}

function openEventStream(req, res) {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no'
  });
  res.write('retry: 3000\n\n');

  const heartbeat = setInterval(() => {
    try {
      sendEvent(res, 'ping', { ts: new Date().toISOString() });
    } catch {
      clearInterval(heartbeat);
    }
  }, 25000);

  const onProxyUpdate = (payload) => sendEvent(res, 'proxy-update', payload);
  const onScanStatus = (payload) => sendEvent(res, 'scan-status', payload);

  liveFeed.on('proxy-update', onProxyUpdate);
  liveFeed.on('scan-status', onScanStatus);

  req.on('close', () => {
    clearInterval(heartbeat);
    liveFeed.off('proxy-update', onProxyUpdate);
    liveFeed.off('scan-status', onScanStatus);
  });
}

async function withScanLock(reason, fn) {
  if (scanBusy) {
    logger.warn('scan.skip', { reason, message: 'job already running' });
    liveFeed.emit('scan-status', { reason, status: 'skipped', ts: new Date().toISOString() });
    return { skipped: true, reason };
  }

  scanBusy = true;
  liveFeed.emit('scan-status', { reason, status: 'running', ts: new Date().toISOString() });

  try {
    const result = await fn();
    liveFeed.emit('scan-status', { reason, status: 'ok', result, ts: new Date().toISOString() });
    return result;
  } catch (err) {
    liveFeed.emit('scan-status', { reason, status: 'error', error: err.message, ts: new Date().toISOString() });
    throw err;
  } finally {
    scanBusy = false;
  }
}

async function runScrape(reason, opts = {}) {
  return await withScanLock(reason, async () => {
    return await scrapeAndProcess({
      config,
      logger,
      saveProxySnapshot,
      setState: saveState,
      getState,
      modeReason: reason,
      ...opts,
      onProxyUpdate: (payload) => liveFeed.emit('proxy-update', payload)
    });
  });
}

async function runDailyRescan(reason = 'daily-rescan') {
  return await withScanLock(reason, async () => {
    return await rescanSavedProxies({
      config,
      logger,
      saveProxySnapshot,
      setState: saveState,
      getState,
      modeReason: reason,
      onProxyUpdate: (payload) => liveFeed.emit('proxy-update', payload)
    });
  });
}

function startDailyRescanScheduler() {
  if (dailyRescanTimer || !config.scheduler?.enabled) return;
  dailyRescanTimer = setInterval(() => {
    runDailyRescan('daily-rescan').catch((err) => logger.error('rescan.error', { error: err.message, stack: err.stack }));
  }, DAILY_RESCAN_MS);

  const state = getState();
  const last = state.lastDailyRescanAt ? Date.parse(state.lastDailyRescanAt) : 0;
  if (!last || Number.isNaN(last) || Date.now() - last >= DAILY_RESCAN_MS) {
    setTimeout(() => {
      runDailyRescan('daily-rescan:startup').catch((err) => logger.error('rescan.error', { error: err.message, stack: err.stack }));
    }, 5000);
  }
}

async function handleApi(req, res, urlObj) {
  const pathname = urlObj.pathname;

  if (req.method === 'GET' && pathname === '/api/events') {
    return openEventStream(req, res);
  }

  if (req.method === 'GET' && pathname === '/api/status') {
    const state = getState();
    const proxies = getProxySnapshot();
    return sendJSON(res, 200, {
      ok: true,
      scheduler: scheduler.getStatus(),
      state,
      counts: {
        http: proxies.http.length,
        https: proxies.https.length,
        socks4: proxies.socks4.length,
        socks5: proxies.socks5.length,
        total: proxies.http.length + proxies.https.length + proxies.socks4.length + proxies.socks5.length
      },
      updatedAt: state.lastRunAt || null
    });
  }

  if (req.method === 'GET' && pathname === '/api/logs') {
    const limit = Math.min(Number(urlObj.searchParams.get('limit') || 120), 500);
    const logs = logger.tail(limit);
    return sendJSON(res, 200, { ok: true, logs });
  }

  if (req.method === 'GET' && pathname === '/api/proxies') {
    const type = normalizeType(urlObj.searchParams.get('type'));
    const proxies = getProxySnapshot();
    return sendText(res, 200, proxies[type].join('\n') + (proxies[type].length ? '\n' : ''), 'text/plain; charset=utf-8');
  }

  if (req.method === 'GET' && pathname === '/api/export') {
    const license = urlObj.searchParams.get('license') || '';
    const type = normalizeType(urlObj.searchParams.get('type'));
    const ip = req.socket.remoteAddress || 'unknown';
    const limitPerMinute = Number(config.security?.maxExportPerMinute || 120);
    if (!canExport(ip + ':' + license, limitPerMinute)) {
      return sendJSON(res, 429, { ok: false, error: 'Rate limit export tercapai.' });
    }
    const validation = licenseManager.validateLicense(license);
    if (!validation.ok) {
      return sendJSON(res, 403, { ok: false, error: validation.error || 'License tidak valid.' });
    }
    const proxies = getProxySnapshot();
    const body = proxies[type].join('\n') + (proxies[type].length ? '\n' : '');
    return sendText(res, 200, body, 'text/plain; charset=utf-8');
  }

  if (req.method === 'POST' && pathname === '/api/scheduler/start') {
    if (!adminAuth(req)) return unauthorized(res);
    scheduler.start();
    saveState({ ...getState(), schedulerRunning: scheduler.getStatus().running });
    return sendJSON(res, 200, { ok: true, scheduler: scheduler.getStatus() });
  }

  if (req.method === 'POST' && pathname === '/api/scheduler/stop') {
    if (!adminAuth(req)) return unauthorized(res);
    scheduler.stop();
    saveState({ ...getState(), schedulerRunning: scheduler.getStatus().running });
    return sendJSON(res, 200, { ok: true, scheduler: scheduler.getStatus() });
  }

  if (req.method === 'POST' && pathname === '/api/scrape/run') {
    if (!adminAuth(req)) return unauthorized(res);
    const result = await runScrape('manual');
    return sendJSON(res, 200, { ok: true, result, scheduler: scheduler.getStatus() });
  }

  if (req.method === 'POST' && pathname === '/api/test') {
    if (!adminAuth(req)) return unauthorized(res);
    const body = await parseBody(req);
    const type = normalizeType(body.type || 'http');
    const mode = body.mode === 'method2' ? 'method2' : 'method1';
    const result = await runScrape(`test:${mode}`, {
      forcedType: type,
      forcedMode: mode,
      dryRun: true
    });
    return sendJSON(res, 200, { ok: true, result });
  }

  if (req.method === 'GET' && pathname === '/api/licenses') {
    if (!adminAuth(req)) return unauthorized(res);
    return sendJSON(res, 200, { ok: true, licenses: licenseManager.listLicenses() });
  }

  if (req.method === 'POST' && pathname === '/api/licenses') {
    if (!adminAuth(req)) return unauthorized(res);
    const body = await parseBody(req);
    const days = Number(body.days || 0);
    const note = String(body.note || '');
    const license = licenseManager.createLicense({ days, note });
    logger.info('license.create', { license: license.key, expiresAt: license.expiresAt || null });
    return sendJSON(res, 201, { ok: true, license });
  }

  if (req.method === 'POST' && pathname.startsWith('/api/licenses/') && pathname.endsWith('/revoke')) {
    if (!adminAuth(req)) return unauthorized(res);
    const id = pathname.split('/')[3];
    const updated = licenseManager.revokeLicense(id);
    if (!updated) return notFound(res, 'License tidak ditemukan');
    logger.warn('license.revoke', { id });
    return sendJSON(res, 200, { ok: true });
  }

  if (req.method === 'POST' && pathname === '/api/method') {
    if (!adminAuth(req)) return unauthorized(res);
    const body = await parseBody(req);
    const mode = body.mode === 'method2' ? 'method2' : 'method1';
    const state = getState();
    state.activeMode = mode;
    saveState(state);
    logger.info('runtime.method.changed', { mode });
    return sendJSON(res, 200, { ok: true, activeMode: mode });
  }

  if (req.method === 'POST' && pathname === '/api/refresh') {
    if (!adminAuth(req)) return unauthorized(res);
    const result = await runScrape('refresh');
    return sendJSON(res, 200, { ok: true, result });
  }

  return notFound(res);
}

async function requestHandler(req, res) {
  const urlObj = new URL(req.url, `http://${req.headers.host || '127.0.0.1'}`);
  try {
    if (urlObj.pathname.startsWith('/api/')) {
      return await handleApi(req, res, urlObj);
    }

    const filePath = urlObj.pathname === '/' ? '/index.html' : urlObj.pathname;
    const abs = path.join(PUBLIC_DIR, filePath);
    return serveStatic(res, abs, PUBLIC_DIR);
  } catch (err) {
    logger.error('server.error', { message: err.message, stack: err.stack });
    return sendJSON(res, 500, { ok: false, error: 'Internal server error' });
  }
}

async function bootstrap() {
  const stateExists = fs.existsSync(STATE_PATH);
  const currentState = getState();
  if (!stateExists) {
    saveState({
      createdAt: new Date().toISOString(),
      lastRunAt: null,
      lastRunStatus: 'idle',
      lastDailyRescanAt: null,
      lastDailyRescanStatus: 'idle',
      activeMode: currentState.activeMode || 'method1',
      schedulerRunning: scheduler.getStatus().running
    });
  }

  if (!fs.existsSync(PROXIES_PATH)) saveProxySnapshot({ http: [], https: [], socks4: [], socks5: [] });

  if (config.scheduler?.enabled) scheduler.start();
  startDailyRescanScheduler();
  saveState({
    ...getState(),
    schedulerRunning: scheduler.getStatus().running
  });

  const server = http.createServer(requestHandler);
  server.listen(config.server?.port || 5000, config.server?.host || '127.0.0.1', () => {
    const addr = server.address();
    logger.info('server.start', { host: config.server?.host || '127.0.0.1', port: addr.port });
    console.log(`Dashboard ready at http://${config.server?.host || '127.0.0.1'}:${addr.port}`);
    console.log(`Admin token: ${config.security?.adminToken || '(none)'}`);
  });
}

bootstrap().catch((err) => {
  console.error(err);
  process.exit(1);
});
