Letakkan file `proxy.go` Anda di folder ini jika ingin menggunakan metode 2.

Contoh konfigurasi default memakai:
- command: `go`
- args: `run tools/proxy.go`

Anda bebas mengganti `data/config.json` agar sesuai dengan argumen asli dari tool Anda.
