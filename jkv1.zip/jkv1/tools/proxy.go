package main

import (
	"bufio"
	"flag"
	"fmt"
	"io"
	"net"
	"os"
	"strings"
	"sync"
	"time"
)

type proxy struct {
	host string
	port string
	raw  string
}

func parseProxy(line string) (proxy, bool) {
	line = strings.TrimSpace(line)
	line = strings.TrimPrefix(line, "http://")
	line = strings.TrimPrefix(line, "https://")
	line = strings.TrimPrefix(line, "socks4://")
	line = strings.TrimPrefix(line, "socks5://")
	if line == "" || strings.HasPrefix(line, "#") {
		return proxy{}, false
	}
	parts := strings.Split(line, ":")
	if len(parts) < 2 {
		return proxy{}, false
	}
	host := strings.Join(parts[:len(parts)-1], ":")
	port := parts[len(parts)-1]
	if host == "" || port == "" {
		return proxy{}, false
	}
	return proxy{host: host, port: port, raw: host + ":" + port}, true
}

func readLines(path string) ([]string, error) {
	var r io.Reader
	if path == "" || path == "-" {
		r = os.Stdin
	} else {
		f, err := os.Open(path)
		if err != nil {
			return nil, err
		}
		defer f.Close()
		r = f
	}
	var lines []string
	s := bufio.NewScanner(r)
	for s.Scan() {
		lines = append(lines, s.Text())
	}
	return lines, s.Err()
}

func checkProxy(p proxy, targetHost string, targetPort int, timeout time.Duration) bool {
	conn, err := net.DialTimeout("tcp", net.JoinHostPort(p.host, p.port), timeout)
	if err != nil {
		return false
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(timeout))
	req := fmt.Sprintf("CONNECT %s:%d HTTP/1.1\r\nHost: %s:%d\r\nProxy-Connection: Keep-Alive\r\n\r\n", targetHost, targetPort, targetHost, targetPort)
	if _, err := conn.Write([]byte(req)); err != nil {
		return false
	}
	buf := make([]byte, 1024)
	n, err := conn.Read(buf)
	if err != nil {
		return false
	}
	resp := string(buf[:n])
	return strings.Contains(resp, "200")
}

func main() {
	var inputPath string
	var outputPath string
	var targetHost string
	var targetPort int
	var concurrency int
	var timeoutMs int

	flag.StringVar(&inputPath, "input", "-", "input file path")
	flag.StringVar(&outputPath, "output", "-", "output file path")
	flag.StringVar(&targetHost, "target-host", "example.com", "target host for CONNECT")
	flag.IntVar(&targetPort, "target-port", 443, "target port for CONNECT")
	flag.IntVar(&concurrency, "concurrency", 25, "concurrent workers")
	flag.IntVar(&timeoutMs, "timeout-ms", 12000, "timeout in ms")
	flag.Parse()

	lines, err := readLines(inputPath)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}

	var proxies []proxy
	seen := map[string]struct{}{}
	for _, line := range lines {
		p, ok := parseProxy(line)
		if !ok {
			continue
		}
		if _, exists := seen[p.raw]; exists {
			continue
		}
		seen[p.raw] = struct{}{}
		proxies = append(proxies, p)
	}

	jobs := make(chan proxy)
	results := make(chan string, len(proxies))
	var wg sync.WaitGroup
	for i := 0; i < concurrency; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for p := range jobs {
				if checkProxy(p, targetHost, targetPort, time.Duration(timeoutMs)*time.Millisecond) {
					results <- p.raw
				}
			}
		}()
	}

	go func() {
		for _, p := range proxies {
			jobs <- p
		}
		close(jobs)
		wg.Wait()
		close(results)
	}()

	alive := make([]string, 0, len(proxies))
	for r := range results {
		alive = append(alive, r)
	}

	if outputPath == "" || outputPath == "-" {
		for _, line := range alive {
			fmt.Println(line)
		}
		return
	}
	if err := os.WriteFile(outputPath, []byte(strings.Join(alive, "\n")+func() string { if len(alive)>0 { return "\n" }; return "" }()), 0644); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
