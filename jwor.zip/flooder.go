package main

import (
	"crypto/tls"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// Warna ANSI
const (
	reset  = "\033[0m"
	hijau  = "\033[32m"
	kuning = "\033[33m"
	merah  = "\033[31m"
	ungu   = "\033[35m"
)

// Fungsi untuk mendapatkan warna berdasarkan status code
func warnaStatus(code int) string {
	switch {
	case code >= 200 && code < 300:
		return hijau
	case code >= 300 && code < 400:
		return kuning
	case code >= 400 && code < 500:
		return merah
	case code >= 500 && code < 600:
		return ungu
	default:
		return merah // untuk error (0) atau lainnya
	}
}

func main() {
	// Default values
	var (
		ua       = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
		cookie   = ""
		referrer = ""
		debug    = false
	)

	// Args: url proxy rps duration [--flag value ...]
	if len(os.Args) < 5 {
		fmt.Println("Usage: app <url> <proxy> <rps> <duration> [--ua '...'] [--cookie '...'] [--referrer '...'] [--debug]")
		fmt.Println("Example: app https://example.com 127.0.0.1:8080 10 60 --ua 'Mozilla/5.0' --cookie 'session=123' --referrer 'https://google.com' --debug")
		return
	}

	target := os.Args[1]
	proxyAddr := os.Args[2]
	rps, _ := strconv.Atoi(os.Args[3])
	duration, _ := strconv.Atoi(os.Args[4])

	// Manual parse flags (mulai dari argumen ke-5)
	for i := 5; i < len(os.Args); i++ {
		arg := os.Args[i]
		switch arg {
		case "--ua":
			if i+1 < len(os.Args) {
				ua = os.Args[i+1]
				i++
			}
		case "--cookie":
			if i+1 < len(os.Args) {
				cookie = os.Args[i+1]
				i++
			}
		case "--referrer":
			if i+1 < len(os.Args) {
				referrer = os.Args[i+1]
				i++
			}
		case "--debug":
			debug = true
		}
	}

	// DEBUG: tampilkan parsed values
	if debug {
		fmt.Println("=== PARSED VALUES ===")
		fmt.Printf("Target: %s\n", target)
		fmt.Printf("Proxy: %s\n", proxyAddr)
		fmt.Printf("RPS: %d\n", rps)
		fmt.Printf("Duration: %d\n", duration)
		fmt.Printf("UA: '%s'\n", ua)
		fmt.Printf("Cookie: '%s'\n", cookie)
		fmt.Printf("Referrer: '%s'\n", referrer)
		fmt.Println("====================")
	}

	proxyURL, _ := url.Parse("http://" + proxyAddr)

	// TLS Config
	tlsConfig := &tls.Config{
		InsecureSkipVerify: true,
		NextProtos:         []string{"h2", "http/1.1"},
		MinVersion:         tls.VersionTLS12,
		MaxVersion:         tls.VersionTLS13,
		CipherSuites: []uint16{
			tls.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,
			tls.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305,
			tls.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305,
			tls.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,
			tls.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,
		},
		CurvePreferences: []tls.CurveID{
			tls.X25519,
			tls.CurveP256,
		},
	}

	client := &http.Client{
		Timeout: 8 * time.Second,
		Transport: &http.Transport{
			Proxy:               http.ProxyURL(proxyURL),
			TLSClientConfig:     tlsConfig,
			MaxIdleConns:        100,
			MaxIdleConnsPerHost: 100,
			MaxConnsPerHost:     0,
			DisableCompression:  true,
			DisableKeepAlives:   false,
			ForceAttemptHTTP2:   true,
		},
	}

	interval := time.Duration(1000/rps) * time.Millisecond
	ticker := time.NewTicker(interval)
	defer ticker.Stop()

	// Stats
	var mu sync.Mutex
	statusCodes := make(map[int]int)
	var totalRequests uint64
	var startTime time.Time

	totalRequestsTarget := rps * duration

	fmt.Printf("🔗 Proxy: %s\n", proxyAddr)
	fmt.Printf("📍 Target: %s\n", target)
	fmt.Printf("📊 Rate: %d RPS | Duration: %d detik | Total: %d request\n", rps, duration, totalRequestsTarget)
	fmt.Println("----------------------------------------")

	// Goroutine print stats tiap 5 detik dengan format baru dan warna
	go func() {
		tickerStats := time.NewTicker(5 * time.Second)
		defer tickerStats.Stop()

		for range tickerStats.C {
			mu.Lock()
			if len(statusCodes) > 0 {
				total := 0
				parts := []string{}
				for code, count := range statusCodes {
					total += count
					ratePerStatus := float64(count) / 5.0
					// Warna pada angka status
					warna := warnaStatus(code)
					parts = append(parts, fmt.Sprintf("%s%d%s: %d (%.0f/s)", warna, code, reset, count, ratePerStatus))
				}
				statusStr := strings.Join(parts, ", ")
				statusCodes = make(map[int]int)
				mu.Unlock()

				fmt.Printf("%s Status: %s\n", proxyAddr, statusStr)
			} else {
				mu.Unlock()
			}
		}
	}()

	startTime = time.Now()
	var wg sync.WaitGroup

	for i := 1; i <= totalRequestsTarget; i++ {
		<-ticker.C
		atomic.AddUint64(&totalRequests, 1)

		wg.Add(1)
		go func(reqNum int) {
			defer wg.Done()

			req, err := http.NewRequest("GET", target, nil)
			if err != nil {
				mu.Lock()
				statusCodes[0]++
				mu.Unlock()
				return
			}

			// Set headers
			req.Header.Set("User-Agent", ua)
			if cookie != "" {
				req.Header.Set("Cookie", cookie)
			}
			if referrer != "" {
				req.Header.Set("Referer", referrer)
			}
			// (headers lain dikomentari, bisa diaktifkan jika diperlukan)

			// Debug headers request pertama
			if debug && reqNum == 1 {
				fmt.Println("=== REQUEST HEADERS ===")
				for key, values := range req.Header {
					for _, value := range values {
						fmt.Printf("%s: %s\n", key, value)
					}
				}
				fmt.Println("========================")
			}

			resp, err := client.Do(req)
			if err != nil {
				mu.Lock()
				statusCodes[0]++
				mu.Unlock()
				return
			}
			defer resp.Body.Close()

			// Debug response pertama
			if debug && reqNum == 1 {
				fmt.Println("=== RESPONSE HEADERS ===")
				for key, values := range resp.Header {
					for _, value := range values {
						fmt.Printf("%s: %s\n", key, value)
					}
				}
				fmt.Printf("Status: %s\n", resp.Status)
				fmt.Println("=========================")
			}

			mu.Lock()
			statusCodes[resp.StatusCode]++
			mu.Unlock()
		}(i)
	}

	wg.Wait()
	elapsed := time.Since(startTime)

	// Final stats dengan warna
	mu.Lock()
	fmt.Println("\n----------------------------------------")
	fmt.Printf("📊 FINAL STATS - Proxy: %s\n", proxyAddr)
	total := 0
	for code, count := range statusCodes {
		total += count
		warna := warnaStatus(code)
		if code == 0 {
			fmt.Printf("%s❌ Error: %d%s\n", warna, count, reset)
		} else {
			fmt.Printf("%s✅ Status %d%s: %d\n", warna, code, reset, count)
		}
	}
	fmt.Printf("📊 Total: %d request dalam %v\n", total, elapsed)
	if elapsed.Seconds() > 0 {
		fmt.Printf("📊 Rata-rata RPS: %.2f\n", float64(total)/elapsed.Seconds())
	}
	mu.Unlock()
}
